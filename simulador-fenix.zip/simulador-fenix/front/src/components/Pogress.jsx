import { Check } from "lucide-react";

export default function Pogress({ currentStep }) {
  const steps = ["Dados Pessoais", "Dados Financeiro", "Resultado"];
  return (
    <div className="w-full flex justify-between pb-8">
      {steps?.map((step, i) => (
        <div
          key={i}
          className={`step-item ${currentStep === i && "active"} ${i < currentStep && "complete"}`}
        >
          <div className="step">
            {(i < currentStep) ? <Check size={20} /> : i + 1}
          </div>
          <p className="text-gray-600">{step}</p>
        </div>
      ))}
    </div>
  );
}
