import { useMemo, useState } from "react";
import { CheckCheck, ChevronLeft, ChevronRight } from "lucide-react";

import UserDataForm1 from "./UserDataForm1";
import UserDataForm2 from "./UserDataForm2";
import ResultForm from "./ResultForm";

import useForm from "../hooks/useForm";
import Pogress from "./Pogress";

const formTemplate = {
  email: "",
  dataNascimento: "",
  dataInicioDescontos: "",
  valorInicialContribuicao: "",
  rendimentoMensalBruto: "",
  idadeReforma: "55",
  pensaoReforma: "",
};

export default function Form() {
  const [data, setData] = useState(formTemplate);
  const btnavc = document.querySelectorAll(".avc")

  const updateFieldHandler = (key, value) => {
    setData((prev) => {
      return { ...prev, [key]: value };
    });
  };

  const formComponents = useMemo(
    () => [
      <UserDataForm1
        key="1"
        data={data}
        updateFieldHandler={updateFieldHandler}
      />,
      <UserDataForm2
        key="2"
        data={data}
        updateFieldHandler={updateFieldHandler}
      />,
      <ResultForm key="3" data={data} />,
    ],
    [data]
  );

  const { currentStep, currentComponent, changeStep, isLastStep, isFirstStep } =
    useForm(formComponents);

    function barrarValMin(e) {

      
      if(currentStep === 1){
        if(data.valorInicialContribuicao < 1000){
          e.preventDefault();
        }
      }
    }

  return (
    <>
      <form
        onSubmit={(e) => changeStep(currentStep + 1, e)}
        className="max-w-xl w-full h-full bg-white flex flex-col items-center gap-5 p-8 rounded-lg lg:rounded-none lg:rounded-tr-xl lg:rounded-br-xl"
      >
        <Pogress currentStep={currentStep} />
        <div className="flex flex-col gap-4 w-full">{currentComponent}</div>

        <div className="flex w-full justify-end gap-4 mt-5">
          {!isFirstStep && (
            <button
              type="button"
              className="flex items-center justify-center py-2 px-4 gap-1 text-white text-base bg-slate-800 hover:bg-slate-900 transition-colors rounded-md avc"
              onClick={() => changeStep(currentStep - 1)}
            >
              <ChevronLeft size={20} />
              <span>Voltar</span>
            </button>
          )}

          {!isLastStep && (
            <button
              type="submit"
              onClick={barrarValMin}
              className="flex items-center justify-center py-2 px-4 gap-1 text-white text-base bg-blue-600 hover:bg-blue-700 rounded-md"
            >
              <span>{currentStep === 1 ? "Simular" : "Avançar"}</span>
              {currentStep === 1 ? (
                <CheckCheck size={20} />
              ) : (
                <ChevronRight size={20} />
              )}
            </button>
          )}
        </div>
      </form>
    </>
  );
}
