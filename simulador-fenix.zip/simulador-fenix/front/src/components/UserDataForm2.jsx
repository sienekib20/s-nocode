import React, { useState } from "react";

export default function UserDataForm2({ data, updateFieldHandler }) {
  const [mostrarMB, setMostrarMB] = useState("");
  const [mostrarVM, setMostrarVM] = useState("");
  const [labelVisivel2, setLabelVisivel2] = useState(false);

  function converterMB(valor) {
    let divisor = valor.split(",");
    let numeros = divisor[0].replace(/[^0-9]/g, ""); // Remove todos os caracteres que não são números
    if (divisor[1]) {
      divisor[1] = divisor[1].replace(/[^0-9]/g, "");
      if (divisor[1].length > 2) {
        numeros += divisor[1][2];
      }
      if (divisor[1].length == 1) {
        if (numeros.length > 1) {
          numeros = numeros.slice(0, -1);
        } else {
          numeros = "";
        }
      }
    }

    if (numeros.length > 12) {
      // Se o comprimento for maior que 12, limite o valor aos primeiros 12 caracteres
      numeros = numeros.slice(0, 12);
    } //else if(numeros.length < 4)
    if (numeros[0] == 0) {
      numeros = "";
    }
    var resultado = formatarinputvalor(numeros);

    setMostrarMB(resultado[0]);
    data.rendimentoMensalBruto = resultado[1];
  }

  function converterVM(valor) {
    let divisor = valor.split(",");
    let numeros = divisor[0].replace(/[^0-9]/g, ""); // Remove todos os caracteres que não são números
    if (divisor[1]) {
      divisor[1] = divisor[1].replace(/[^0-9]/g, "");
      if (divisor[1].length > 2) {
        numeros += divisor[1][2];
      }
      if (divisor[1].length == 1) {
        if (numeros.length > 1) {
          numeros = numeros.slice(0, -1);
        } else {
          numeros = "";
        }
      }
    }

    if (numeros.length > 12) {
      // Se o comprimento for maior que 12, limite o valor aos primeiros 12 caracteres
      numeros = numeros.slice(0, 12);
    } //else if(numeros.length < 4)
    if (numeros[0] == 0) {
      numeros = "";
    }

    var resultado = formatarinputvalor(numeros);

    setMostrarVM(resultado[0]);
    data.valorInicialContribuicao = resultado[1];
    if (data.valorInicialContribuicao < 1000) {
      setLabelVisivel2(true);
    } else {
      setLabelVisivel2(false);
    }
  }

  function formatarinputvalor(valor) {
    let valoraMostrar = "";
    let valorOriginal = "";
    let tamanho;

    valorOriginal += valor;

    //--------------------
    if (valorOriginal.length > 9) {
      tamanho = (valorOriginal.length % 9) - 1;
    } else if (valorOriginal.length > 6) {
      tamanho = valorOriginal.length % 6;
      if (tamanho > 0) {
        tamanho -= 1;
      }
    } else {
      tamanho = valorOriginal.length - 4;
    }

    for (let j = 0; j < valorOriginal.length; j++) {
      valoraMostrar += valorOriginal[j];

      if (j == tamanho && valorOriginal.length - 1 > j) {
        tamanho += 3;
        valoraMostrar += ".";
      }
    }
    if (valoraMostrar) {
      valoraMostrar += ",00";
    }
    return [valoraMostrar, valorOriginal];
  }

  return (
    <>
      <div className="flex flex-col gap-2">
        <label htmlFor="rendimentoMensalBruto" className="text-black">
          Rendimento mensal bruto
        </label>
        <input
          type="text"
          name="rendimentoMensalBruto"
          id="rendimentoMensalBruto"
          className="w-full rounded-md py-3 border-none focus:ring-gray-700 bg-gray-200 focus:bg-white placeholder:border-gray-700 text-black"
          value={mostrarMB || ""}
          onChange={(e) => converterMB(e.target.value)}
        />
      </div>
      <div className="flex flex-col gap-2">
        <label htmlFor="valorInicialContribuicao" className="text-black">
          Contribuição mensal <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          name="valorInicialContribuicao"
          required
          id="valorInicialContribuicao"
          className="w-full rounded-md py-3 border-none focus:ring-gray-700 bg-gray-200 focus:bg-white placeholder:border-gray-700 text-black"
          value={mostrarVM || ""}
          onChange={(e) => converterVM(e.target.value)}
        />
        {labelVisivel2 == true && (
          <label className="text-sm text-red-600">valor mínimo permitido é de 1.000,00 Kzs</label>
        )}{" "}
      </div>
      <div className="flex flex-col gap-2">
        <label htmlFor="idadeReforma" className="text-black">
          Idade pretendida para a reforma{" "}
          <span className="text-red-500">*</span>
        </label>
        <select
          name="idadeReforma"
          id="idadeReforma"
          className="w-full rounded-md py-3 border-none focus:ring-gray-700 bg-gray-200 focus:bg-white placeholder:border-gray-700 text-black"
          value={data.idadeReforma || "55"}
          onChange={(e) => updateFieldHandler("idadeReforma", e.target.value)}
        >
          {[55, 56, 57, 58, 59, 60].map((idade) => (
            <option key={idade} value={idade}>
              {idade}
            </option>
          ))}
        </select>
      </div>
    </>
  );
}
