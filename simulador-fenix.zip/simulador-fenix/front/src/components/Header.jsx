export default function Header() {
  return (
    <>
      <header className="w-full h-full flex flex-col lg:flex-row justify-start lg:justify-center items-center lg:items-start gap-4 lg:gap-10 py-2 px-1">
        <a href="https://fenix.ayka.ao">
          <img
            src="/logo.png"
            alt="Fénix Pensões Logo"
            className="max-w-xs w-96"
          />
        </a>
        <h2 className="text-xl md:text-2xl lg:text-4xl font-bold text-white lg:text-blue-600 lg:pt-5 leading-relaxed text-center lg:text-left">
          Simulador de Fundo de Pensão
        </h2>
      </header>
    </>
  );
}
