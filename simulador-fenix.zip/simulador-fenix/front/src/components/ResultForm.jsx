import { PDFDownloadLink } from "@react-pdf/renderer";
import PDF from "./PDF";
import { useEffect, useMemo, useState } from "react";
import { calcularContribuicoes } from "../utils/valorTotalContribuicoes";
import { calcularFundoFinal } from "../utils/valorFundoFinal";

export default function ResultForm({ data }) {
  let {
    email,
    dataNascimento,
    dataInicioDescontos,
    valorInicialContribuicao,
    rendimentoMensalBruto,
    idadeReforma,
  } = data;

  const dataNascimentoNova = new Date(dataNascimento);
  const dataAtual = new Date();
  const diferencaEmMilissegundos = dataAtual - dataNascimentoNova;
  const idadeInicial = Math.floor(
    diferencaEmMilissegundos / (1000 * 60 * 60 * 24 * 365.25)
  );

  const dataInicioDescontosNovo = new Date(dataInicioDescontos);
  const inicioDescontos = dataAtual - dataInicioDescontosNovo;
  const dataDeDescontos = Math.floor(
    inicioDescontos / (1000 * 60 * 60 * 24 * 365.25)
  );

  const diaAtual = dataAtual.getDate();
  const mesAtual = dataAtual.getMonth() + 1;
  const anoAtual = dataAtual.getFullYear();

  const [resultados, setResultados] = useState([]);
  const [totalContribuicoes, setTotalContribuicoes] = useState(0);
  const [valorFundoFinal, setValorFundoFinal] = useState([]);
  const [valorFundoFinalTotal, setValorFundoFinalTotal] = useState(0);
  const taxaDeCrescimento = 0.03; // Taxa de crescimento (3.0% convertida para decimal)

  var item = resultados.map((item) => item.contribuicao);
  var contribuicaoAnual = item[0];

  // FORMULA TOTAL CONTRIBUICÃO
  useEffect(() => {
    calcularContribuicoes(
      idadeInicial,
      idadeReforma,
      valorInicialContribuicao,
      setResultados,
      setTotalContribuicoes,
      taxaDeCrescimento
    );

    calcularFundoFinal(
      idadeInicial,
      idadeReforma,
      contribuicaoAnual,
      taxaDeCrescimento,
      setValorFundoFinal,
      setValorFundoFinalTotal
    );
  }, [contribuicaoAnual]);

  let kwanza = new Intl.NumberFormat("pt-AO", {
    style: "currency",
    currency: "AOA",
  });

  // ========== ENVIAR PDF ============
  function enviarPDF() {
    baixarArquivo();
  }

  async function baixarArquivo() {
    try {
      let link;
      const auxpdf = document.querySelectorAll(".pass-pdf").forEach((e) => {
        link = e.getAttribute("href");
      });
      const response = await fetch(link); // Faz o download do arquivo
      if (response.ok) {
        const blob = await response.blob(); // Converte a resposta em um objeto Blob

        let aq = [];

        const reader = new FileReader();
        reader.onload = function (event) {
          const base64URL = event.target.result;

          //-------------------------------------------------------------

          const update = {
            email: email,
            link: base64URL.split(",")[1],
          };

          const options = {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(update),
          };

          fetch(`${import.meta.env.VITE_API_URL}/email`, options)
            .then((response) => {
              if (!response.ok) {
                throw new Error("erro");
              }
              return response.json();
            })
            .then((res) => {
              //é aqui onde vem a resposta do email, 1 se foi enviado e 0 caso ocorra um erro. -----------------------------------------------------------------------
            })
            .catch((error) => {
              console.error(error);
            });

          // Aqui você pode manipular o conteúdo do arquivo conforme necessário
        };

        reader.readAsDataURL(blob);
      } else {
        console.error("Erro ao baixar o arquivo");
      }
    } catch (error) {
      console.error("Erro ao processar o download: ", error);
    }
  }

  //-------------------------- final ENVIAR PDF
  const anosDeContribuicao = idadeInicial - idadeReforma;
  const anosDeContribuicaoPositivo = Math.abs(anosDeContribuicao);
  const fundoFinalTotal = Math.round(valorFundoFinalTotal);
  const rendimentoAcomulado = totalContribuicoes - fundoFinalTotal;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-2">
        <p>
          Idade atual: {idadeInicial} {idadeInicial > 1 ? "anos" : "ano"}
        </p>
        {rendimentoMensalBruto && <p>Rendimento mensal bruto: {kwanza.format(rendimentoMensalBruto)}</p>}
        <p>Contribuição mensal: {kwanza.format(valorInicialContribuicao)}</p>
        <p>Valor total investido: {kwanza.format(totalContribuicoes)}</p>
        <p>
          Rendimento acumulado: {kwanza.format(Math.abs(rendimentoAcomulado))}
        </p>
        <p>
          Valor bruto acumulado no fim do prazo:{" "}
          {kwanza.format(fundoFinalTotal)}
        </p>
        <p>
          Início de descontos: {dataDeDescontos}{" "}
          {dataDeDescontos > 1 ? "anos" : "ano"}
        </p>
        <p>
          Anos de contribuição: {Math.abs(anosDeContribuicaoPositivo)}{" "}
          {anosDeContribuicaoPositivo > 1 ? "anos" : "ano"}
        </p>
        <p>Idade de reforma pretendida: {idadeReforma} anos</p>
      </div>

      {/* Text Note */}
      <div className="flex items-center">
        <span className="font-medium text-sm leading-relaxed text-center">
          <span className="text-black font-bold">Nota:</span> Os valores que serão apresentados no final desta simulação são
          apenas estimativas, não constituindo qualquer garantia de
          concretização.
        </span>
      </div>

      <div className="w-full flex justify-between gap-2">
        <PDFDownloadLink
          document={
            <PDF
              data={data}
              idadeInicial={idadeInicial}
              dataDeDescontos={dataDeDescontos}
              kwanza={kwanza}
              anosDeContribuicaoPositivo={anosDeContribuicaoPositivo}
              resultados={resultados}
              totalContribuicoes={totalContribuicoes}
              fundoFinalTotal={fundoFinalTotal}
              rendimentoAcomulado={rendimentoAcomulado}
              valorFundoFinal={valorFundoFinal}
            />
          }
          fileName={`simulação-fénix_${diaAtual}-${mesAtual}-${anoAtual}.pdf`}
          className="w-full flex items-center justify-center py-2 px-4 gap-1 font-medium text-white text-base bg-blue-600 hover:bg-blue-700 rounded-md pass-pdf"
        >
          {({ loading }) => (loading ? "Gerando PDF..." : "Baixar PDF")}
        </PDFDownloadLink>
        {email && (
          <button
            onClick={enviarPDF}
            className="w-full flex items-center justify-center py-2 px-4 gap-1 text-white text-base bg-orange-600 hover:bg-orange-500 rounded-md"
          >
            Receber por Email
          </button>
        )}
      </div>
    </div>
  );
}
