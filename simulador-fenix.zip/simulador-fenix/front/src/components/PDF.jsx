import {
  Page,
  Text,
  View,
  Document,
  StyleSheet,
  Image,
  Link,
} from "@react-pdf/renderer";

const styles = StyleSheet.create({
  page: {
    flexDirection: "column",
    backgroundColor: "#ffffff",
  },
  header: {
    width: "100%",
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
    padding: "20px 20px",
  },
  logo: {
    width: "200px",
    height: "65px",
    marginLeft: "8px",
  },
  title: {
    fontSize: "24px",
    color: "#2759bc",
    fontWeight: "bold",
    width: "300px",
    lineHeight: 1.5,
  },
  space: {
    height: "27px",
  },
  section: {
    position: "relative",
    gap: "10px",
    flexGrow: 1,
    padding: "0 20px 20px",
    fontSize: "12px",
  },
  sectionTitle: {
    fontWeight: "bold",
    fontSize: "16px",
    marginBottom: "12px",
  },
  Imagesection: {
    width: "540px",
    position: "absolute",
    left: "-280px",
    transform: "rotate(90deg)",
    opacity: 0.1,
  },
  sectionInfo: {
    width: "350px",
    paddingLeft: "30px",
    gap: "7px",
  },
  resultTable: {
    margin: "0 auto",
    alignItems: "flex-start",
    width: "85%",
    borderStyle: "solid",
    borderColor: "#ffffff",
    borderWidth: 1,
    borderRightWidth: 0,
    borderBottomWidth: 0,
  },
  table: {
    margin: "12px auto 0",
    alignItems: "center",
    width: "85%",
    borderStyle: "solid",
    borderColor: "#ffffff",
    borderWidth: 1,
    borderRightWidth: 0,
    borderBottomWidth: 0,
  },
  tableRow: {
    margin: "auto",
    flexDirection: "row",
  },
  tableCol: {
    width: "50%",
    borderStyle: "solid",
    borderColor: "#ffffff",
    borderWidth: 1,
    borderLeftWidth: 0,
    borderTopWidth: 0,
  },
  resultCol: {
    width: "50%",
    borderStyle: "solid",
    borderColor: "#ffffff",
    borderWidth: 1,
    borderLeftWidth: 0,
    borderTopWidth: 0,
  },
  tableHeader: {
    backgroundColor: "#ff6200",
    color: "#ffffff",
    fontSize: 12,
    padding: "8px",
  },
  tableCell: {
    backgroundColor: "#d8dbff",
    color: "#333",
    fontSize: 11,
    padding: "8px",
  },
  footer: {
    position: "relative",
    width: "100%",
    alignItems: "center",
    justifyContent: "space-between",
    borderTop: "1px",
    borderStyle: "solid",
    borderTopColor: "#333",
    color: "#2759bc",
    padding: "16px 0 32px",
    marginTop: "16px",
    fontSize: 10,
    bottom: 0,
  },
  footerInfo: {
    right: "120px",
    gap: "8px",
  },
  footerLink: {
    textDecoration: "none",
    color: "#2759bc",
  },
  Imagefooter: {
    width: "350px",
    position: "absolute",
    right: "-135px",
    bottom: "-110px",
  },
});

export default function PDF({
  data,
  idadeInicial,
  dataDeDescontos,
  totalContribuicoes,
  anosDeContribuicaoPositivo,
  kwanza,
  resultados,
  fundoFinalTotal,
  rendimentoAcomulado,
}) {
  let { valorInicialContribuicao, rendimentoMensalBruto, idadeReforma } = data;

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        <View style={styles.header}>
          <Image src="/logo.png" style={styles.logo} />
          <Text style={styles.title}>SIMULAÇÃO DE POUPANÇA REFORMA</Text>
        </View>
        <View fixed style={styles.space}></View>
        <View style={styles.section}>
          <Image src="/triangulos.png" style={styles.Imagesection} />
          <View style={styles.sectionInfo}>
            <Text style={styles.sectionTitle}>Dados:</Text>
            <Text>Idade atual: {idadeInicial} anos</Text>
            <Text>
              Anos de contribuição: {anosDeContribuicaoPositivo}{" "}
              {anosDeContribuicaoPositivo > 1 ? "anos" : "ano"}
            </Text>
            <Text>Idade de reforma pretendida: {idadeReforma} anos</Text>
            <Text>
              Início de descontos: {dataDeDescontos}{" "}
              {dataDeDescontos > 1 ? "anos" : "ano"}
            </Text>
          </View>
          {/* First */}
          <View style={styles.table}>
            <View style={styles.tableRow}>
              <View style={styles.tableCol}>
                <Text style={styles.tableHeader}>Idade</Text>
              </View>
              <View style={styles.tableCol}>
                <Text style={styles.tableHeader}>Contribuição anual</Text>
              </View>
            </View>
            {resultados.map((item) => (
              <View key={item.ano} style={styles.tableRow}>
                <View style={styles.tableCol}>
                  <Text style={styles.tableCell}>{item.ano}</Text>
                </View>
                <View style={styles.tableCol}>
                  <Text style={styles.tableCell}>
                    {kwanza.format(item.contribuicao)}
                  </Text>
                </View>
              </View>
            ))}
          </View>

          {/* Result Table */}
          <View>
            {/* Second */}
            <View style={styles.resultTable}>
              <View style={styles.tableRow}>
                <View style={styles.resultCol}>
                  <Text style={styles.tableHeader}>Contribuição mensal</Text>
                </View>
                <View style={styles.resultCol}>
                  <Text style={styles.tableCell}>
                    {kwanza.format(valorInicialContribuicao)}
                  </Text>
                </View>
              </View>
              <View style={styles.tableRow}>
                <View style={styles.resultCol}>
                  <Text style={styles.tableHeader}>Valor total investido</Text>
                </View>
                <View style={styles.resultCol}>
                  <Text style={styles.tableCell}>
                    <Text>{kwanza.format(totalContribuicoes)}</Text>
                  </Text>
                </View>
              </View>
              <View style={styles.tableRow}>
                <View style={styles.resultCol}>
                  <Text style={styles.tableHeader}>Rendimento acumulado</Text>
                </View>
                <View style={styles.resultCol}>
                  <Text style={styles.tableCell}>
                    <Text>{kwanza.format(Math.abs(rendimentoAcomulado))}</Text>
                  </Text>
                </View>
              </View>
              <View style={styles.tableRow}>
                <View style={styles.resultCol}>
                  <Text style={styles.tableHeader}>
                    Valor bruto acumulado no fim do prazo
                  </Text>
                </View>
                <View style={styles.resultCol}>
                  <Text style={styles.tableCell}>
                    <Text>{kwanza.format(fundoFinalTotal)}</Text>
                  </Text>
                </View>
              </View>
              {rendimentoMensalBruto &&
              <View style={styles.tableRow}>
                <View style={styles.resultCol}>
                  <Text style={styles.tableHeader}>
                    Rendimento mensal bruto
                  </Text>
                </View>
                
                 <View style={styles.resultCol}>
                  <Text style={styles.tableCell}>
                    <Text>{kwanza.format(rendimentoMensalBruto)}</Text>
                  </Text>
                </View>
              </View>}
            </View>
          </View>
        </View>
        <View fixed style={styles.footer}>
          <View style={styles.footerInfo}>
            <Text>Fénix – Sociedade Gestora de Fundos de Pensões, S.A.</Text>
            <Link
              src="mailto:suporte@fenixpensoes.ao"
              style={styles.footerLink}
            >
              geral@fenixpensoes.ao
            </Link>
            <Link
              src="https://goo.gl/maps/SZXkHieo1k6p2cuA8"
              style={styles.footerLink}
            >
              Rua Principal do Patriota, Zona Financeira–Edificio Chimoio
            </Link>
          </View>
          <Image style={styles.Imagefooter} src="/triangulos.png" />
        </View>
      </Page>
    </Document>
  );
}
