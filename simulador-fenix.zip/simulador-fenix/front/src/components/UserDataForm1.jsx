export default function UserDataForm1({ data, updateFieldHandler }) {
  const dataAtual = new Date().getFullYear();
  const minAge = 18;
  const maxAge = 55;
  const minDate = new Date(dataAtual - maxAge, 0, 1);
  const maxDate = new Date(dataAtual - minAge, 0, 0);
  const maxDateToday = new Date();

  const formatDate = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  };

  return (
    <>
      <div className="flex flex-col gap-2">
        <label htmlFor="email" className="text-black">
          Email
        </label>
        <input
          autoFocus
          type="email"
          name="email"
          id="email"
          placeholder="Digite seu email"
          className="w-full rounded-md py-3 border-none focus:ring-gray-700 bg-gray-200 focus:bg-white placeholder:border-gray-700 text-black"
          value={data.email || ""}
          onChange={(e) => updateFieldHandler("email", e.target.value)}
        />
      </div>
      <div className="flex flex-col gap-2">
        <label htmlFor="dataNascimento" className="text-black">
          Data de nascimento <span className="text-red-500">*</span>
        </label>
        <input
          type="date"
          name="dataNascimento"
          id="dataNascimento"
          min={formatDate(minDate)}
          max={formatDate(maxDate)}
          className="w-full rounded-md py-3 border-none focus:ring-gray-700 bg-gray-200 focus:bg-white placeholder:border-gray-700 text-black"
          required
          value={data.dataNascimento || ""}
          onChange={(e) => updateFieldHandler("dataNascimento", e.target.value)}
        />
      </div>
      <div className="flex flex-col gap-2">
        <label htmlFor="dataInicioDescontos" className="text-black">
          Data de início dos descontos <span className="text-red-500">*</span>
        </label>
        <input
          type="date"
          name="dataInicioDescontos"
          id="dataInicioDescontos"
          max={formatDate(maxDateToday)}
          className="w-full rounded-md py-3 border-none focus:ring-gray-700 bg-gray-200 focus:bg-white placeholder:border-gray-700 text-black"
          required
          value={data.dataInicioDescontos || ""}
          onChange={(e) =>
            updateFieldHandler("dataInicioDescontos", e.target.value)
          }
        />
      </div>
    </>
  );
}
