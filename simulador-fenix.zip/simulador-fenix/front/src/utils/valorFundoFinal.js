export const calcularFundoFinal = (
  idadeInicial,
  idadeReforma,
  contribuicaoAnual,
  taxaDeCrescimento,
  setValorFundoFinal,
  setValorFundoFinalTotal
) => {
  const resultadosFundo = [];
  const taxaRendibilidadeAnual = 0.05; // Taxa de rendibilidade anual (5%)
  const comissaoEmissao = 0.05; // Comissão de emissão (5%)
  const periodicidadeContribuicao = 12; // Periodicida de contribuicao = 12

  let valorInvestimento = 0;
  let resultadoTotal = 0;

  for (let idade = idadeInicial; idade < idadeReforma; idade++) {
    valorInvestimento *= 1 + taxaRendibilidadeAnual;
    var valordeaplicacao =
      (contribuicaoAnual / periodicidadeContribuicao) * (1 - comissaoEmissao);
    var taxaderentabilidadeanual =
      Math.pow(1 + taxaRendibilidadeAnual, 1 / periodicidadeContribuicao) - 1;

    //valorfuturo=valordeaplicacao*(1+taxaderentabilidadeanual)**12;
    var calculo1 = (1 + taxaderentabilidadeanual) ** 12;
    var calculo2 = (calculo1 - 1) / taxaderentabilidadeanual;
    var valorfuturo =
      valordeaplicacao * calculo2 * (1 + taxaderentabilidadeanual);
    valorInvestimento += valorfuturo;

    contribuicaoAnual *= 1 + taxaDeCrescimento;

    if (idade == idadeReforma - 1) {
      resultadoTotal = valorInvestimento;
    }

    resultadosFundo.push({
      idade: idade,
      fundoFinal: valorInvestimento.toFixed(2),
    });
  }

  setValorFundoFinalTotal(resultadoTotal);
  setValorFundoFinal(resultadosFundo);
};
