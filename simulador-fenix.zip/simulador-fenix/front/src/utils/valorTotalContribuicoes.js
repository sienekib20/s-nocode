// FORMULA TOTAL CONTRIBUICÃO
export const calcularContribuicoes = (
  idadeInicial,
  idadeReforma,
  valorInicialContribuicao,
  setResultados,
  setTotalContribuicoes,
  taxaDeCrescimento
) => {
  const valoresDeContribuicaoPorAno = [];
  let valorContribuicaoAnual = valorInicialContribuicao * 12; // Inicialize o valor da contribuição anual com o primeiro ano

  for (let idade = idadeInicial; idade < idadeReforma; idade++) {
    valoresDeContribuicaoPorAno.push({
      ano: idade,
      contribuicao: valorContribuicaoAnual,
    });

    valorContribuicaoAnual *= 1 + taxaDeCrescimento;
  }

  const valorTotalInvestido = valoresDeContribuicaoPorAno.reduce(
    (total, item) => total + item.contribuicao,
    0
  );

  return (
    setResultados(valoresDeContribuicaoPorAno),
    setTotalContribuicoes(Math.round(valorTotalInvestido))
  )
}
