import Form from "./components/Form";
import Header from "./components/Header";

function App() {
  return (
    <div className="w-full h-full flex flex-col bg-hero-form lg:bg-none bg-cover p-4 lg:py-8 lg:px-4">
      <Header />
      <div className="max-w-6xl w-full h-full flex lg:flex-row items-center justify-center md:shadow-lg lg:rounded-xl mx-auto  lg:bg-hero-form bg-cover py-4 lg:py-0 lg:my-8">
        <div className="w-full h-full hidden lg:flex"></div>
        <Form />
      </div>
    </div>
  );
}

export default App;
