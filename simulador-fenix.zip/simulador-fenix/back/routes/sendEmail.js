import nodemailer from "nodemailer";
import fetch from "node-fetch";
import { Blob, Response } from "node-fetch";

const emailHTML = `
<html lang="pt-AO">
<head><meta http-equiv="Content-Type" content="text/html charset=UTF-8" /></head>
<body style="background-color:#f6f9fc;padding:10px 0;color:#000;">
  <table align="center" role="presentation" cellSpacing="0" cellPadding="0" border="0" width="100%"
    style="max-width:37.5em;background-color:#ffffff;border:1px solid #f0f0f0;padding:45px">
    <tr style="width:100%">
      <td><img alt="Fénix Pensões" src="cid:icon" width="50" height="50" style="display:block;outline:none;border:none;text-decoration:none" />
        <table align="center" border="0" cellPadding="0" cellSpacing="0" role="presentation" width="100%">
          <tbody>
            <tr>
              <td>
                <p style="font-size:16px;line-height:26px;margin:24px 0 0;">
                  Apresentamos o resultado da sua simulação de pensão. Como solicitado, anexamos o arquivo em formato PDF.
                </p>
                <p style="font-size:16px;line-height:26px;margin:8px 0 32px;">
                Por favor, revise o arquivo anexado e entre em contacto connosco se tiver alguma dúvida ou visite <a target="_blank" style="color: #0f25ff;text-decoration:underline" href="https://fenixpensoes.ao/">nosso site para obter mais informações.</a>
              </p>
                <p style="font-size:16px;line-height:26px;margin:16px 0;">
                  &copy; Todos os direitos Reservados - Fénix Pensões
                </p>
              </td>
            </tr>
          </tbody>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
`;

export async function sendEmail(email, url) {
  try {
    let val = url;

    const transporter = nodemailer.createTransport({
      service: "gmail",
      host: "smtp.gmail.com",
      port: 587,
      secure: false, // true for 465, false for other ports
      auth: {
        type: "login",
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    const info = await transporter.sendMail({
      from: `"Fénix Pensões" <${process.env.EMAIL_USER}>`, // endereço entiade
      to: email, // list of receivers
      subject: "Resultado da simulação - Fénix Pensões", // Assunto
      text: "Este é o resultado da sua simulação", // plain text body
      html: emailHTML, // html body
      attachments: [
        {
          filename: "Simulação-Fénix.pdf",
          content: val,
          encoding: "base64",
        },
        { filename: "icon.png", path: "./icon.png", cid: "icon" },
      ],
    });

    return 1;
  } catch (error) {
    return 0;
  }
}

// URL Blob

// Função para converter o URL Blob em um arquivo PDF
async function convertUrlBlobToPdf(urlBlob) {
  try {
    // Faça o download do Blob da URL
    const response = await fetch(urlBlob);
    const blobData = await response.blob();

    // Converta o Blob em um ArrayBuffer
    const arrayBuffer = await new Response(blobData).arrayBuffer();

    // Crie um novo Blob a partir do ArrayBuffer com o tipo "application/pdf"
    const pdfBlob = new Blob([arrayBuffer], { type: "application/pdf" });

    // Retorna o Blob do novo PDF
    return pdfBlob;
  } catch (error) {
    console.error("Erro ao converter o URL Blob em PDF:", error);
    throw error;
  }
}
