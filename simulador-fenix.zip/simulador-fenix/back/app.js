import express from "express";
import dotenv from "dotenv";
import { sendEmail } from "./routes/sendEmail.js";
import cors from "cors";
import bodyParser from "body-parser";

dotenv.config();

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: "1000mb" }));
app.use(bodyParser.urlencoded({ extended: true, limit: "1000mb" }));
app.use(express.json());

const port = 3050;
app.listen(port, console.log(`Servidor rodando: http://localhost:${port}`));

app.post("/email", async (req, res) => {
  try {
    const passar = req.body;

   let result= await sendEmail(passar.email, passar.link);
    res.json(result);
  } catch (error) {
    console.error("rota error:", error);
  }
});

app.get("/", (req, res) => {
  res.send({ msg: "Bem vindo a nossa API!" });
});
